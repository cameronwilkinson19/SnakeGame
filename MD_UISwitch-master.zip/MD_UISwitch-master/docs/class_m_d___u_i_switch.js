var class_m_d___u_i_switch =
[
    [ "keyResult_t", "class_m_d___u_i_switch.html#a117cd39685e6017f17e942b1d7cbea03", [
      [ "KEY_NULL", "class_m_d___u_i_switch.html#a117cd39685e6017f17e942b1d7cbea03ab732e9179752afecef5eb841d7a7ebdf", null ],
      [ "KEY_PRESS", "class_m_d___u_i_switch.html#a117cd39685e6017f17e942b1d7cbea03a15e40279fddacdbb32dd91654747945d", null ],
      [ "KEY_DPRESS", "class_m_d___u_i_switch.html#a117cd39685e6017f17e942b1d7cbea03ac2243c722c18d06421d166e8fa3a133d", null ],
      [ "KEY_LONGPRESS", "class_m_d___u_i_switch.html#a117cd39685e6017f17e942b1d7cbea03aa96ef0b5c7f6169701f6ae6d5fa7bc20", null ],
      [ "KEY_RPTPRESS", "class_m_d___u_i_switch.html#a117cd39685e6017f17e942b1d7cbea03af3457ee4d710d0cc77d760cfc23670b8", null ]
    ] ],
    [ "state_t", "class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092a", [
      [ "S_IDLE", "class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aa81457b7aa0e5d24254e54a87887d5f5d", null ],
      [ "S_DEBOUNCE1", "class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aaafe996a22bc3c0b1ea85ea2201006e0e", null ],
      [ "S_DEBOUNCE2", "class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aa02717d8933e18d99dbf500e5511fb196", null ],
      [ "S_PRESS", "class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aab30cefbee0e52f140753e5baf513d7b0", null ],
      [ "S_DPRESS", "class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aac5c355168e1d2dc56b8b3adc724e4767", null ],
      [ "S_LPRESS", "class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aaab53aea191537b04767a7022c85e1d84", null ],
      [ "S_REPEAT", "class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aae46a21d7cc139db9851249d7c8f4f0a4", null ],
      [ "S_WAIT", "class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aa661dfbdc773bfd9f948e47ee17220efa", null ]
    ] ],
    [ "MD_UISwitch", "class_m_d___u_i_switch.html#a5495560f26e383b94a246ec750427df6", null ],
    [ "~MD_UISwitch", "class_m_d___u_i_switch.html#a9f64d570dff58f36b097731213f2e50e", null ],
    [ "begin", "class_m_d___u_i_switch.html#a34c53422ced4f432f08565aff276c8bd", null ],
    [ "enableDoublePress", "class_m_d___u_i_switch.html#a0581e504add30a9763426c96bc4ffb35", null ],
    [ "enableLongPress", "class_m_d___u_i_switch.html#aaf8424f5f69243637ec296530ac57ef1", null ],
    [ "enableRepeat", "class_m_d___u_i_switch.html#a62b4c58fe1db440e44e66d54389f588d", null ],
    [ "enableRepeatResult", "class_m_d___u_i_switch.html#ac5190407be944cb37ed0b2e9f06ee925", null ],
    [ "getKey", "class_m_d___u_i_switch.html#aac77b8bbdb44597e76a3c675c8844f7a", null ],
    [ "processFSM", "class_m_d___u_i_switch.html#a87f6a0e4b6ff3da09b1a84a1cd816230", null ],
    [ "read", "class_m_d___u_i_switch.html#a617982b74a11dfa6ce5d5b0ee977abb2", null ],
    [ "setDebounceTime", "class_m_d___u_i_switch.html#a437e04ee557dbac7598529acd89be51a", null ],
    [ "setDoublePressTime", "class_m_d___u_i_switch.html#ac29e353ed13dc39671c221201ed1d8c4", null ],
    [ "setLongPressTime", "class_m_d___u_i_switch.html#acddb4bac7da9b76b2ffb64b5fd301c2d", null ],
    [ "setRepeatTime", "class_m_d___u_i_switch.html#a758aeea794e3c2ea3b0270e7d71fc04d", null ],
    [ "_enableFlags", "class_m_d___u_i_switch.html#aa92f25ce35fc3a2f6d458ca5d9b95b56", null ],
    [ "_lastKey", "class_m_d___u_i_switch.html#afbf4adfda419da86355e31e645ce71a1", null ],
    [ "_lastKeyIdx", "class_m_d___u_i_switch.html#a037dc1bd6b01dbfa4a2101a27913f781", null ],
    [ "_state", "class_m_d___u_i_switch.html#a637d10dfdd1ce03d0d99793024d9d13a", null ],
    [ "_timeActive", "class_m_d___u_i_switch.html#af8088c6ba1b4c581e0f04951a1017663", null ],
    [ "_timeDebounce", "class_m_d___u_i_switch.html#ae666b71094edccf25a39f53ecc311f6e", null ],
    [ "_timeDoublePress", "class_m_d___u_i_switch.html#a4dc9cf90297ab2a8af69c5a032aa872c", null ],
    [ "_timeLongPress", "class_m_d___u_i_switch.html#a1458feab310d6192e2b397d0015cfd8f", null ],
    [ "_timeRepeat", "class_m_d___u_i_switch.html#acbaa5fe4ca9e6826f254e31af86a91b1", null ]
];