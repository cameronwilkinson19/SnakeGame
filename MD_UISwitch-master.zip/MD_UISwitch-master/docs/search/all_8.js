var searchData=
[
  ['longpress_5fenable',['LONGPRESS_ENABLE',['../_m_d___u_i_switch_8h.html#ae624d1696ade653ff7302c5d6a8055e0',1,'MD_UISwitch.h']]]
];
