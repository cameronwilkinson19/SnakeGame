var searchData=
[
  ['adcthreshold',['adcThreshold',['../struct_m_d___u_i_switch___analog_1_1ui_analog_keys__t.html#a51ba62699536cd09340108f2ecddfd9d',1,'MD_UISwitch_Analog::uiAnalogKeys_t']]],
  ['adctolerance',['adcTolerance',['../struct_m_d___u_i_switch___analog_1_1ui_analog_keys__t.html#a7b94b4c903e5cb89e3b13fa8ba72c06e',1,'MD_UISwitch_Analog::uiAnalogKeys_t']]]
];
