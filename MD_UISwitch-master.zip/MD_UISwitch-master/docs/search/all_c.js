var searchData=
[
  ['s_5fdebounce1',['S_DEBOUNCE1',['../class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aaafe996a22bc3c0b1ea85ea2201006e0e',1,'MD_UISwitch']]],
  ['s_5fdebounce2',['S_DEBOUNCE2',['../class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aa02717d8933e18d99dbf500e5511fb196',1,'MD_UISwitch']]],
  ['s_5fdpress',['S_DPRESS',['../class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aac5c355168e1d2dc56b8b3adc724e4767',1,'MD_UISwitch']]],
  ['s_5fidle',['S_IDLE',['../class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aa81457b7aa0e5d24254e54a87887d5f5d',1,'MD_UISwitch']]],
  ['s_5flpress',['S_LPRESS',['../class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aaab53aea191537b04767a7022c85e1d84',1,'MD_UISwitch']]],
  ['s_5fpress',['S_PRESS',['../class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aab30cefbee0e52f140753e5baf513d7b0',1,'MD_UISwitch']]],
  ['s_5frepeat',['S_REPEAT',['../class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aae46a21d7cc139db9851249d7c8f4f0a4',1,'MD_UISwitch']]],
  ['s_5fwait',['S_WAIT',['../class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092aa661dfbdc773bfd9f948e47ee17220efa',1,'MD_UISwitch']]],
  ['setdebouncetime',['setDebounceTime',['../class_m_d___u_i_switch.html#a437e04ee557dbac7598529acd89be51a',1,'MD_UISwitch']]],
  ['setdoublepresstime',['setDoublePressTime',['../class_m_d___u_i_switch.html#ac29e353ed13dc39671c221201ed1d8c4',1,'MD_UISwitch']]],
  ['setlongpresstime',['setLongPressTime',['../class_m_d___u_i_switch.html#acddb4bac7da9b76b2ffb64b5fd301c2d',1,'MD_UISwitch']]],
  ['setrepeattime',['setRepeatTime',['../class_m_d___u_i_switch.html#a758aeea794e3c2ea3b0270e7d71fc04d',1,'MD_UISwitch']]],
  ['state_5ft',['state_t',['../class_m_d___u_i_switch.html#a519fd067a5f689ceb1a8c7e8d7c1092a',1,'MD_UISwitch']]]
];
