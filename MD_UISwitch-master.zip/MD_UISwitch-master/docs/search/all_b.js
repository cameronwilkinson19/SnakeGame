var searchData=
[
  ['revision_20history',['Revision History',['../page_revision_history.html',1,'index']]],
  ['read',['read',['../class_m_d___u_i_switch.html#a617982b74a11dfa6ce5d5b0ee977abb2',1,'MD_UISwitch::read()'],['../class_m_d___u_i_switch___digital.html#a354575495b5d5a72b478a2ae57d42dd9',1,'MD_UISwitch_Digital::read()'],['../class_m_d___u_i_switch___analog.html#a87c3c39d6a2f88cd631e06bc71a32187',1,'MD_UISwitch_Analog::read()'],['../class_m_d___u_i_switch___matrix.html#adfebd47b7bd20ccad072b00d4346ab2d',1,'MD_UISwitch_Matrix::read()'],['../class_m_d___u_i_switch__4017_k_m.html#a9a7df04604edc8d0763eb6002d604b74',1,'MD_UISwitch_4017KM::read()']]],
  ['repeat_5fenable',['REPEAT_ENABLE',['../_m_d___u_i_switch_8h.html#a30909fe7f296d7a592876e8f23673801',1,'MD_UISwitch.h']]],
  ['repeat_5fresult_5fenable',['REPEAT_RESULT_ENABLE',['../_m_d___u_i_switch_8h.html#ae64d8ab4bff3ff8fe3474b9e722c6543',1,'MD_UISwitch.h']]],
  ['reset',['reset',['../class_m_d___u_i_switch__4017_k_m.html#a1b9091d79a75512700bd0a1494206e2b',1,'MD_UISwitch_4017KM']]]
];
