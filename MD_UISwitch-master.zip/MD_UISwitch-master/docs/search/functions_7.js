var searchData=
[
  ['setdebouncetime',['setDebounceTime',['../class_m_d___u_i_switch.html#a437e04ee557dbac7598529acd89be51a',1,'MD_UISwitch']]],
  ['setdoublepresstime',['setDoublePressTime',['../class_m_d___u_i_switch.html#ac29e353ed13dc39671c221201ed1d8c4',1,'MD_UISwitch']]],
  ['setlongpresstime',['setLongPressTime',['../class_m_d___u_i_switch.html#acddb4bac7da9b76b2ffb64b5fd301c2d',1,'MD_UISwitch']]],
  ['setrepeattime',['setRepeatTime',['../class_m_d___u_i_switch.html#a758aeea794e3c2ea3b0270e7d71fc04d',1,'MD_UISwitch']]]
];
