var struct_m_d___u_i_switch___analog_1_1ui_analog_keys__t =
[
    [ "adcThreshold", "struct_m_d___u_i_switch___analog_1_1ui_analog_keys__t.html#a51ba62699536cd09340108f2ecddfd9d", null ],
    [ "adcTolerance", "struct_m_d___u_i_switch___analog_1_1ui_analog_keys__t.html#a7b94b4c903e5cb89e3b13fa8ba72c06e", null ],
    [ "value", "struct_m_d___u_i_switch___analog_1_1ui_analog_keys__t.html#a0ea22aef058780c13a36dd8e3080674a", null ]
];